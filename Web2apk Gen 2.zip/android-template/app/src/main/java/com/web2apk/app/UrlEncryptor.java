package com.web2apk.app;

import android.util.Base64;
import java.util.Arrays;

/**
 * URL Decryption utility
 * Decrypts obfuscated URL at runtime
 */
public class UrlEncryptor {
    
    /**
     * Decrypt URL from encrypted parts
     * @param parts Encrypted URL parts (shuffled)
     * @param order Original order of parts
     * @param key Decryption key (package name)
     * @return Decrypted URL
     */
    public static String decrypt(String[] parts, int[] order, String key) {
        try {
            // Step 1: Reorder parts
            StringBuilder reordered = new StringBuilder();
            String[] orderedParts = new String[parts.length];
            for (int i = 0; i < order.length; i++) {
                orderedParts[order[i]] = parts[i];
            }
            for (String part : orderedParts) {
                reordered.append(part);
            }
            
            // Step 2: Base64 decode
            byte[] decoded = Base64.decode(reordered.toString(), Base64.NO_WRAP);
            
            // Step 3: XOR decrypt
            byte[] keyBytes = generateKey(key);
            byte[] decrypted = new byte[decoded.length];
            for (int i = 0; i < decoded.length; i++) {
                decrypted[i] = (byte) (decoded[i] ^ keyBytes[i % keyBytes.length]);
            }
            
            return new String(decrypted, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
    
    /**
     * Generate XOR key from package name
     */
    private static byte[] generateKey(String packageName) {
        // Create a consistent key from package name
        byte[] base = packageName.getBytes();
        byte[] key = new byte[16];
        for (int i = 0; i < 16; i++) {
            key[i] = (byte) (base[i % base.length] ^ (i * 17 + 42));
        }
        return key;
    }
}
